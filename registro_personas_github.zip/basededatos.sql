
CREATE DATABASE IF NOT EXISTS registro_personas;
USE registro_personas;

CREATE TABLE sexo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    descripcion VARCHAR(20) NOT NULL
);

CREATE TABLE estado_civil (
    id INT AUTO_INCREMENT PRIMARY KEY,
    descripcion VARCHAR(20) NOT NULL
);

CREATE TABLE persona (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    telefono VARCHAR(20),
    direccion TEXT,
    sexo_id INT,
    estado_civil_id INT,
    FOREIGN KEY (sexo_id) REFERENCES sexo(id),
    FOREIGN KEY (estado_civil_id) REFERENCES estado_civil(id)
);
