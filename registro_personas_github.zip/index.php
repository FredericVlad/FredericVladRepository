
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro de Personas</title>
    <link rel="stylesheet" href="vista/css/estilos.css">
</head>
<body>
    <h1>Registro de Datos Personales</h1>
    <form action="controlador/PersonaController.php" method="POST">
        <input type="text" name="nombre" placeholder="Nombre completo" required><br>
        <input type="text" name="telefono" placeholder="Teléfono" required><br>
        <input type="text" name="direccion" placeholder="Dirección" required><br>
        <select name="sexo">
            <option value="M">Masculino</option>
            <option value="F">Femenino</option>
        </select><br>
        <select name="estado_civil">
            <option value="Soltero">Soltero</option>
            <option value="Casado">Casado</option>
            <option value="Divorciado">Divorciado</option>
        </select><br>
        <button type="submit">Registrar</button>
    </form>
</body>
</html>
